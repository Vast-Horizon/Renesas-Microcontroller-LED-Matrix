/* YouTube Video:
 * https://youtu.be/eJjiB8V7uj8?si=Jl4A3eS-HAQRmUBm
 * */

#include "hal_data.h"
#include <stdio.h>
#include <stdlib.h>

//General functions
void init_gpio();
void SwitchGame();
void resetLEDs();
size_t scanPressedButton();

//Tic-Tac-Toe functions
void scanKeypadAndControlLEDs();
void WinOrLose();
void EndGameBlinkingLED(size_t*, size_t);
void resetLEDs();
size_t NextPlayer();

//Whac-A-Mole functions
void scanKeypadWAM();
void resetWhiteLEDs();
size_t randomLED();
void hpUpdate();

size_t WhichGame = 0;

//Whac-A-Mole Parameters
size_t startLevel = 2000;//Initial whac a mole delay is 2s
size_t level = 0;
size_t levelIncrement = 100; //Shorten by 0.1s every time
size_t gameState = 0; //If 0, game is in idle mode
size_t levelCounter = 1; // Counts number of level achieved when game ends
size_t blinkLED = 0; //position of the whac a mole blinking LED
size_t hp = 3; //whac a mole hp



// Define GPIO pins for LEDs
const ioport_port_pin_t GreenLedPins[] = {
      IOPORT_PORT_06_PIN_10,
      IOPORT_PORT_06_PIN_09,
      IOPORT_PORT_06_PIN_08,
      IOPORT_PORT_06_PIN_05,
      IOPORT_PORT_06_PIN_04,
      IOPORT_PORT_06_PIN_03,
      IOPORT_PORT_06_PIN_02,
      IOPORT_PORT_06_PIN_01,
      IOPORT_PORT_06_PIN_00
};
const ioport_port_pin_t WhiteLedPins[] = {
      IOPORT_PORT_05_PIN_06,
      IOPORT_PORT_05_PIN_07,
      IOPORT_PORT_05_PIN_11,
      IOPORT_PORT_05_PIN_12,
      IOPORT_PORT_05_PIN_13,
      IOPORT_PORT_01_PIN_11,
      IOPORT_PORT_01_PIN_12,
      IOPORT_PORT_01_PIN_13,
      IOPORT_PORT_01_PIN_14

};
const ioport_port_pin_t RGBPins[] = {

     IOPORT_PORT_08_PIN_00, //R
     IOPORT_PORT_01_PIN_15, //Y
     IOPORT_PORT_00_PIN_10 //G

};

// Define GPIO pins for keypad rows (outputs)
const ioport_port_pin_t keypadRowPins[] = {
   IOPORT_PORT_03_PIN_07,
   IOPORT_PORT_03_PIN_08,
   IOPORT_PORT_03_PIN_09,
   IOPORT_PORT_03_PIN_10
};

// Define GPIO pins for keypad columns (inputs)
const ioport_port_pin_t keypadColPins[] = {
   IOPORT_PORT_03_PIN_11,
   IOPORT_PORT_03_PIN_12,
   IOPORT_PORT_03_PIN_03,
   IOPORT_PORT_04_PIN_00
};

void init_gpio() {
    for (size_t i = 0; i < sizeof(GreenLedPins) / sizeof(GreenLedPins[0]); i++) {
        g_ioport.p_api->pinWrite(GreenLedPins[i], IOPORT_LEVEL_LOW);
    }
    for (size_t i = 0; i < sizeof(WhiteLedPins) / sizeof(WhiteLedPins[0]); i++) {
        g_ioport.p_api->pinWrite(WhiteLedPins[i], IOPORT_LEVEL_LOW);
    }
    for (size_t i = 0; i < sizeof(keypadRowPins) / sizeof(keypadRowPins[0]); i++) {
        g_ioport.p_api->pinWrite(keypadRowPins[i], IOPORT_LEVEL_LOW);
    }

}

size_t randomLED(){
    size_t randomNum = (size_t)(rand() % 9);
    g_ioport.p_api->pinWrite(WhiteLedPins[randomNum], IOPORT_LEVEL_HIGH);

    return randomNum;
}

void resetWhiteLEDs(){
    for (uint32_t j = 0; j < 9; j++) {
        g_ioport.p_api->pinWrite(WhiteLedPins[j], 0);
    }
}

void resetLEDs(){
    for (uint32_t j = 0; j < 9; j++) {
        g_ioport.p_api->pinWrite(GreenLedPins[j], 0);
    }
    for (uint32_t j = 0; j < 9; j++) {
        g_ioport.p_api->pinWrite(WhiteLedPins[j], 0);
    }
}

void hpUpdate(){
    if (hp==3){
        g_ioport.p_api->pinWrite(GreenLedPins[8], 1);
        g_ioport.p_api->pinWrite(GreenLedPins[5], 1);
        g_ioport.p_api->pinWrite(GreenLedPins[2], 1);
        g_ioport.p_api->pinWrite(RGBPins[2], 1);
        g_ioport.p_api->pinWrite(RGBPins[1], 1);
        g_ioport.p_api->pinWrite(RGBPins[0], 1);

    }
    else if (hp==2){
        g_ioport.p_api->pinWrite(GreenLedPins[8], 0);
        g_ioport.p_api->pinWrite(GreenLedPins[5], 1);
        g_ioport.p_api->pinWrite(GreenLedPins[2], 1);
        g_ioport.p_api->pinWrite(RGBPins[2], 0);
        g_ioport.p_api->pinWrite(RGBPins[1], 1);
        g_ioport.p_api->pinWrite(RGBPins[0], 1);
    }
    else if (hp==1){
        g_ioport.p_api->pinWrite(GreenLedPins[8], 0);
        g_ioport.p_api->pinWrite(GreenLedPins[5], 0);
        g_ioport.p_api->pinWrite(GreenLedPins[2], 1);
        g_ioport.p_api->pinWrite(RGBPins[2], 0);
        g_ioport.p_api->pinWrite(RGBPins[1], 0);
        g_ioport.p_api->pinWrite(RGBPins[0], 1);
    }
    else if (hp==0){ //END Game and reset
        resetLEDs();
        g_ioport.p_api->pinWrite(RGBPins[2], 0);
        g_ioport.p_api->pinWrite(RGBPins[1], 0);
        g_ioport.p_api->pinWrite(RGBPins[0], 0);
        gameState=0;
        hp=3;
        if(levelCounter>18){
            for (uint32_t j = 0; j < 9; j++) {
                g_ioport.p_api->pinWrite(GreenLedPins[j], 1);
            }
        }
        else if (levelCounter>15&&levelCounter<=18){
            for (uint32_t j = 0; j < 7; j++) {
                g_ioport.p_api->pinWrite(GreenLedPins[j], 1);
            }
        }
        else if (levelCounter>10&&levelCounter<=15){
            for (uint32_t j = 0; j < 4; j++) {
                g_ioport.p_api->pinWrite(GreenLedPins[j], 1);
            }
        }
        else if (levelCounter<=10){
            for (uint32_t j = 0; j < 2; j++) {
                g_ioport.p_api->pinWrite(GreenLedPins[j], 1);
            }
        }
        R_BSP_SoftwareDelay(3000, BSP_DELAY_UNITS_MILLISECONDS);
        SwitchGame();
    }

}

void scanKeypadAndControlLEDs() {
    for (size_t row = 0; row < 3; row++) {
        // Set current row low
        g_ioport.p_api->pinWrite(keypadRowPins[row], IOPORT_LEVEL_LOW);

        for (size_t col = 0; col < 3; col++) {
            ioport_level_t checklevel;
            // Read current column
            g_ioport.p_api->pinRead(keypadColPins[col], &checklevel);

            // If the button is pressed, toggle the corresponding LED
            if (checklevel == IOPORT_LEVEL_LOW) {
                // Calculate the LED index based on the row and column
                size_t ledIndex;
                if(row==0){
                    ledIndex =  col; //index 0, 1, 2
                }
                else if(row==1){
                    ledIndex = 3+col; //index 3, 4, 5
                }
                else if(row==2){
                    ledIndex = 6+col; //index 6, 7, 8
                }

                if (ledIndex < 9) {
                    // Toggle LED
                    ioport_level_t currentGLevel;
                    ioport_level_t currentWLevel;
                    g_ioport.p_api->pinRead(GreenLedPins[ledIndex], &currentGLevel);
                    g_ioport.p_api->pinRead(WhiteLedPins[ledIndex], &currentWLevel);
                    ioport_level_t nextGLevel;
                    ioport_level_t nextWLevel;
                    if (currentGLevel==IOPORT_LEVEL_LOW){
                        nextGLevel=IOPORT_LEVEL_HIGH;
                    }else{nextGLevel=IOPORT_LEVEL_LOW;}

                    if (currentWLevel==IOPORT_LEVEL_LOW){
                        nextWLevel=IOPORT_LEVEL_HIGH;
                    }else{nextWLevel=IOPORT_LEVEL_LOW;}

                    if(currentGLevel==IOPORT_LEVEL_LOW && currentWLevel== IOPORT_LEVEL_LOW){
                        size_t nextPlay = NextPlayer();
                        if(nextPlay==0){
                            g_ioport.p_api->pinWrite(GreenLedPins[ledIndex], nextGLevel);}
                        else if(nextPlay==1){
                            g_ioport.p_api->pinWrite(WhiteLedPins[ledIndex], nextWLevel);}

                    }

                }
            }
        }

        // Set current row high again
        g_ioport.p_api->pinWrite(keypadRowPins[row], IOPORT_LEVEL_HIGH);
    }

}

size_t NextPlayer(){
    ioport_level_t checklevel = IOPORT_LEVEL_LOW;
    size_t g_counter=0;
    size_t w_counter=0;
    for (uint32_t g = 0; g < 9; g++) {
        g_ioport.p_api->pinRead(GreenLedPins[g], &checklevel);
        if (checklevel == 1){
            g_counter+=1;
        }
    }
    for (uint32_t w = 0; w < 9; w++) {
        g_ioport.p_api->pinRead(WhiteLedPins[w], &checklevel);
        if (checklevel == 1){
            w_counter+=1;
        }
    }

    if (g_counter==w_counter){
        return 0;//next player is green
    }
    else if (g_counter>w_counter){
        return 1; //next player is white
    }

    return 2;
}

void WinOrLose(){
    // Checking Horizontal
    for (size_t row = 0; row < 3; row++) {
        ioport_level_t check_level;
        size_t counter=0;
        size_t ledIndex=0;
        for (size_t col = 0; col < 3; col++) {
            if(row==0){
                ledIndex =  col; //index 0, 1, 2
            }
            else if(row==1){
                ledIndex = 3+col; //index 3, 4, 5
            }
            else if(row==2){
                ledIndex = 6+col; //index 6, 7, 8
            }
            g_ioport.p_api->pinRead(GreenLedPins[ledIndex], &check_level);
            if(check_level==IOPORT_LEVEL_HIGH){
                counter+=1;
            }
            if(counter==3){
                if(row==0){
                    size_t index_arry[] = {2,1,0};
                    EndGameBlinkingLED(index_arry,0);
                }
                else if(row==1){
                    size_t index_arry[] = {5,4,3};
                    EndGameBlinkingLED(index_arry,0);
                }
                else if(row==2){
                    size_t index_arry[] = {8,7,6};
                    EndGameBlinkingLED(index_arry,0);
                }

            }
        }
    }

    for (size_t row = 0; row < 3; row++) {
        ioport_level_t check_level;
        size_t counter=0;
        size_t ledIndex=0;
        for (size_t col = 0; col < 3; col++) {
            if(row==0){
                ledIndex =  col; //index 0, 1, 2
            }
            else if(row==1){
                ledIndex = 3+col; //index 3, 4, 5
            }
            else if(row==2){
                ledIndex = 6+col; //index 6, 7, 8
            }
            g_ioport.p_api->pinRead(WhiteLedPins[ledIndex], &check_level);

            if(check_level==IOPORT_LEVEL_HIGH){
                counter+=1;
            }
            if(counter==3){
                if(row==0){
                    size_t index_arry[] = {2,1,0};
                    EndGameBlinkingLED(index_arry,1);
                }
                else if(row==1){
                    size_t index_arry[] = {5,4,3};
                    EndGameBlinkingLED(index_arry,1);
                }
                else if(row==2){
                    size_t index_arry[] = {8,7,6};
                    EndGameBlinkingLED(index_arry,1);
                }

            }
        }
    }

    // Checking Vertical
    for (size_t col = 0; col < 3; col++) {
        ioport_level_t check_level1;
        ioport_level_t check_level2;
        ioport_level_t check_level3;
        g_ioport.p_api->pinRead(GreenLedPins[col], &check_level1);
        g_ioport.p_api->pinRead(GreenLedPins[col+3], &check_level2);
        g_ioport.p_api->pinRead(GreenLedPins[col+6], &check_level3);
        if(check_level1==1&&check_level2==1&&check_level3==1){
            size_t index_arry[] = {col,col+3,col+6};
            EndGameBlinkingLED(index_arry,0);
        }
    }

    for (size_t col = 0; col < 3; col++) {
        ioport_level_t check_level1;
        ioport_level_t check_level2;
        ioport_level_t check_level3;
        g_ioport.p_api->pinRead(WhiteLedPins[col], &check_level1);
        g_ioport.p_api->pinRead(WhiteLedPins[col+3], &check_level2);
        g_ioport.p_api->pinRead(WhiteLedPins[col+6], &check_level3);
        if(check_level1==1&&check_level2==1&&check_level3==1){
            size_t index_arry[] = {col,col+3,col+6};
            EndGameBlinkingLED(index_arry,1);
        }
    }

    // Checking Diagonal
    ioport_level_t check_level0;
    ioport_level_t check_level4;
    ioport_level_t check_level8;
    ioport_level_t check_level2;
    ioport_level_t check_level6;
    g_ioport.p_api->pinRead(GreenLedPins[0], &check_level0);
    g_ioport.p_api->pinRead(GreenLedPins[4], &check_level4);
    g_ioport.p_api->pinRead(GreenLedPins[8], &check_level8);
    g_ioport.p_api->pinRead(GreenLedPins[2], &check_level2);
    g_ioport.p_api->pinRead(GreenLedPins[6], &check_level6);
    if(check_level4==1&&check_level0==1&&check_level8==1){
                size_t index_arry[] = {0,4,8};
                EndGameBlinkingLED(index_arry,0);
            }
    if(check_level4==1&&check_level2==1&&check_level6==1){
                size_t index_arry[] = {2,4,6};
                EndGameBlinkingLED(index_arry,0);
            }

    g_ioport.p_api->pinRead(WhiteLedPins[0], &check_level0);
    g_ioport.p_api->pinRead(WhiteLedPins[4], &check_level4);
    g_ioport.p_api->pinRead(WhiteLedPins[8], &check_level8);
    g_ioport.p_api->pinRead(WhiteLedPins[2], &check_level2);
    g_ioport.p_api->pinRead(WhiteLedPins[6], &check_level6);
    if(check_level4==1&&check_level0==1&&check_level8==1){
                size_t index_arry[] = {0,4,8};
                EndGameBlinkingLED(index_arry,1);
            }
    if(check_level4==1&&check_level2==1&&check_level6==1){
                size_t index_arry[] = {2,4,6};
                EndGameBlinkingLED(index_arry,1);
            }

    // Checking tied
    ioport_level_t checklevel = IOPORT_LEVEL_LOW;
    size_t g_counter=0;
    for (uint32_t g = 0; g < 9; g++) {
        g_ioport.p_api->pinRead(GreenLedPins[g], &checklevel);
        if (checklevel == 1){
            g_counter+=1;
        }
    }
    if (g_counter>=5){
        resetLEDs();
    }

}

void EndGameBlinkingLED(size_t* index_arry, size_t winner){
    const bsp_delay_units_t bsp_delay_units = BSP_DELAY_UNITS_MILLISECONDS;
    const uint32_t delay = 500;

    ioport_level_t checklevel = IOPORT_LEVEL_HIGH;
    size_t numOfBlink = 0;
    size_t index;

    while(numOfBlink<=5)
    {
        if(IOPORT_LEVEL_LOW == checklevel)
        {
            checklevel = IOPORT_LEVEL_HIGH;
        }
        else
        {
            checklevel = IOPORT_LEVEL_LOW;
        }

        if (winner==0){
        for (uint32_t i = 0; i < 3; i++) {
            index = index_arry[i];
            g_ioport.p_api->pinWrite(GreenLedPins[index], checklevel);
        }
        numOfBlink+=1;
        R_BSP_SoftwareDelay(delay, bsp_delay_units);
        }
        else if (winner==1){
            for (uint32_t i = 0; i < 3; i++) {
                index = index_arry[i];
                g_ioport.p_api->pinWrite(WhiteLedPins[index], checklevel);
            }
          numOfBlink+=1;
          R_BSP_SoftwareDelay(delay, bsp_delay_units);
        }

    }

    resetLEDs();
    SwitchGame();

}

size_t scanPressedButton(){
    size_t PBIndex = 99;
    for (size_t row = 0; row < 3; row++) {
        g_ioport.p_api->pinWrite(keypadRowPins[row], IOPORT_LEVEL_LOW);

        for (size_t col = 0; col < 3; col++) {
            ioport_level_t PBlevel;
            g_ioport.p_api->pinRead(keypadColPins[col], &PBlevel);

            // If the button is pressed
            if (PBlevel == IOPORT_LEVEL_LOW) {
                if(row==0){
                    PBIndex =  col; //index 0, 1, 2
                }
                else if(row==1){
                    PBIndex = 3+col; //index 3, 4, 5
                }
                else if(row==2){
                    PBIndex = 6+col; //index 6, 7, 8
                }
            }
        }
        g_ioport.p_api->pinWrite(keypadRowPins[row], IOPORT_LEVEL_HIGH);
    }

    return PBIndex;
}

void scanKeypadWAM() {
    //WAM Game idle until any button is pressed
    if(gameState==0){
        hpUpdate();
        for (uint32_t j = 0; j < 9; j++) {
            g_ioport.p_api->pinWrite(WhiteLedPins[j], 1);
        }
        R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
        for (uint32_t j = 0; j < 9; j++) {
            g_ioport.p_api->pinWrite(WhiteLedPins[j], 0);
        }
        R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);

        for (size_t row = 0; row < 3; row++) {
            g_ioport.p_api->pinWrite(keypadRowPins[row], IOPORT_LEVEL_LOW);

            for (size_t col = 0; col < 3; col++) {
                ioport_level_t PBlevel;
                g_ioport.p_api->pinRead(keypadColPins[col], &PBlevel);

                // If any button is pressed
                if (PBlevel == IOPORT_LEVEL_LOW) {
                    gameState = 1;
                    R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MILLISECONDS);
                }
            }
            g_ioport.p_api->pinWrite(keypadRowPins[row], IOPORT_LEVEL_HIGH);
        }

    }

    else if(gameState == 1)
    {
        blinkLED  = randomLED();
        R_BSP_SoftwareDelay(startLevel-level, BSP_DELAY_UNITS_MILLISECONDS);
        size_t PBIndex = scanPressedButton();

        if(PBIndex==blinkLED){
            level += levelIncrement;
            levelCounter += 1;
            R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
        }else{
            hp -= 1;
            if(hp==0){
                gameState = 0;
            }
            hpUpdate();
            R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);

        }


        //Cap upper speed limit
        if (level >= startLevel)
        {
          level = startLevel;
        }

        //Turn of the LED when every loop is ended
        resetWhiteLEDs();
        R_BSP_SoftwareDelay(startLevel-level, BSP_DELAY_UNITS_MILLISECONDS);
    }



}

void SwitchGame(){
    resetLEDs();
    //keep scanning until 1 or 2 is pressed to make a decision..
      size_t PBpressed = scanPressedButton();
      while(1){
          PBpressed = scanPressedButton();
          if (PBpressed==0){
              WhichGame=0;
              break;
          }
          else if (PBpressed==1){
              WhichGame=1;
              break;
          }
          for (uint32_t j = 0; j < 3; j++) {
              g_ioport.p_api->pinWrite(RGBPins[j], 1);
          }
          R_BSP_SoftwareDelay(250, BSP_DELAY_UNITS_MILLISECONDS);
          for (uint32_t j = 0; j < 3; j++) {
              g_ioport.p_api->pinWrite(RGBPins[j], 0);
          }
          R_BSP_SoftwareDelay(250, BSP_DELAY_UNITS_MILLISECONDS);
      }

      R_BSP_SoftwareDelay(1200, BSP_DELAY_UNITS_MILLISECONDS);

      if (WhichGame==0){
          while (1) {
              scanKeypadAndControlLEDs();
              WinOrLose();
              R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
          }

      }
      else if (WhichGame==1) {
          hpUpdate();
          while (1) {
              scanKeypadWAM();
          }
      }

}

void hal_entry(void) {
    init_gpio();
    SwitchGame();

}
